//////////// Load Products
document.addEventListener("DOMContentLoaded", function () {
    const productListIndex = document.getElementById("product-list");
    const productListShop = document.getElementById("product-list");

    // Fetch products from the JSON file
    fetch("data/products.json")
        .then(response => response.json())
        .then(data => {
            // Check if we are on the index.html page
            if (productListIndex) {
                // Display only the first 3 products on the index page
                const limitedProducts = data.slice(0, 3);
                renderProducts(limitedProducts, productListIndex);
            }

            // Check if we are on the shop.html page
            if (productListShop && window.location.pathname.includes("shop.html")) {
                // Display all products on the shop page
                renderProducts(data, productListShop);
            }
        })
        .catch(error => console.error("Error fetching products:", error));
});

// Function to render products
function renderProducts(products, container) {
    container.innerHTML = ""; // Clear any existing content
    products.forEach(product => {
        const productDiv = document.createElement("div");
        productDiv.classList.add("product");
        productDiv.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>Price: Tk. ${product.price}</p>
            <button class="add-to-cart" data-name="${product.name}" data-price="${product.price}">Add to Cart</button>
        `;
        container.appendChild(productDiv);
    });
}


// /////////Cart Functionality********************
let cart = [];

// Add to Cart
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('add-to-cart')) {
        const product = {
            name: e.target.dataset.name,
            price: parseFloat(e.target.dataset.price),
        };
        cart.push(product);
        updateCart();
    }
});

///// Update Cart
function updateCart() {
    const cartItems = document.getElementById('cart-items');
    const cartTotal = document.getElementById('cart-total');
    cartItems.innerHTML = ''; // Clear previous items
    let total = 0;

    cart.forEach((item, index) => {
        total += item.price;
        cartItems.innerHTML += `
            <li>
                ${item.name} - Tk. ${item.price.toFixed(2)}
                <button class="remove-item" data-index="${index}">Remove</button>
            </li>
        `;
    });

    cartTotal.textContent = `Total: Tk. ${total.toFixed(2)}`;
}

// Remove from Cart
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('remove-item')) {
        const index = e.target.dataset.index;
        cart.splice(index, 1);
        updateCart();
    }
});




////// Load Courses********************
// Fetch and display courses
function loadCourses(limit = null) {
    fetch('data/courses.json')
        .then(response => response.json())
        .then(courses => {
            const courseList = document.getElementById('course-list');
            courseList.innerHTML = ''; // Clear existing content

            // If limit is provided, slice the array
            const displayCourses = limit ? courses.slice(0, limit) : courses;

            displayCourses.forEach(course => {
                const courseElement = document.createElement('div');
                courseElement.classList.add('card');

                courseElement.innerHTML = `
                    <div class="card-image">
                        <img src="${course.image}" alt="${course.name}" loading="lazy">
                    </div>
                    <div class="card-details">
                        <h3 class="card-title">${course.name}</h3>
                        <p class="card-description">${course.description}</p>
                        <p class="price">${course.price}</p>
                        <a href="contact.html" class="btn-secondary">Enroll Now</a>
                    </div>
                `;
                courseList.appendChild(courseElement);
            });
        })
        .catch(error => console.error('Error fetching courses:', error));
}

// Load limited courses on index.html
if (document.body.contains(document.getElementById('course-list')) && window.location.pathname.includes('index.html')) {
    loadCourses(3); // Limit to 3 courses
}

// Load all courses on courses.html
if (document.body.contains(document.getElementById('course-list')) && window.location.pathname.includes('courses.html')) {
    loadCourses(); // Show all courses
}





// Active Link Highlighting/////////////////////////////////
document.addEventListener("DOMContentLoaded", () => {
    // Get all navigation links
    const navLinks = document.querySelectorAll(".nav-links a");
    
    // Get the current page URL
    const currentPage = window.location.href;
    
    // Loop through all navigation links
    navLinks.forEach(link => {
        // Check if the link matches the current page
        if (link.href === currentPage) {
            link.classList.add("active"); // Add the 'active' class to the matching link
        } else {
            link.classList.remove("active"); // Remove the 'active' class from other links
        }
    });
});



//////////////////// slider//////////////////////
let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}


